#include <stdlib.h>

#include "buffer.h"
#include "utils.h"
#include <stdio.h>
#include "string.h"
#include "passwd_generator.h"

void* generate_passwords_thread(void* args) {
	generator_args* arg_struct = (generator_args*) args;

	char alphabet[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k',
			'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

	//TODO Create all permutations of 1 to 5 long words, '
	for (int i = 1; i < 5; i++) {
		for (int j = 0; j < i; j++) {


		}
	}

	//TODO deposit in input ringbuffer
	deposit(buf_1, str);

	pthread_exit(NULL);
}


