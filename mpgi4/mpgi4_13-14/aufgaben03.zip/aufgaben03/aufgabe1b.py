import numpy as np
import matplotlib.pyplot as plt

#TODO

plt.savefig('./figures/aufgabe1b.pdf')
plt.show()
