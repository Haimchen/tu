import numpy as np
import matplotlib.pyplot as plt

#TODO

plt.savefig('./figures/aufgabe1c.pdf')
plt.show()
