# -*- coding: utf-8 -*-
"""
Created on Thu Dec 12 14:52:29 2013

@author: lessig
"""

# imports, system
import numpy as np
import matplotlib.pyplot as plt

# imports, project
from equations import *
from surface import *

def raycast( obj, res) :
    """
    Raycast the given scene and return image of it.

    Inputs:
    obj : object constituting the scene.
    res : resolution of generated image.

    Return:
    image : image of scene
    """

    # create canvas
    image = np.zeros( res, dtype='float64')

    # (x,y) coordinates for fixed viewport [-1.0,1.0] x [-1.0,1.0]
    x_vals = np.linspace( -1.0, 1.0, res[0])
    y_vals = np.linspace( -1.0, 1.0, res[1])

    # iterate over all pixels
    for x_idx, x in enumerate( x_vals) :
        for y_idx, y in enumerate( y_vals) :

            # compute intersection point for current ray
            # (direction is fixed so we do not have to track it)
            ray_origin = np.array( [x, y])
            ipoint = obj.intersect( ray_origin)

            # intersection.size() is zero when there is no intersection
            if ipoint != None:
                # shade object
                image[res[1]-y_idx-1,x_idx] = obj.shade( ipoint)

        print ('%d%%\r') % (100 * x_idx / res[0])
    return image


def main() :

    res = [128, 128]

    # for k, eq in enumerate([heart(), saddle(), rotato(), calypso()]):
    for k, eq in enumerate([heart()]):
        s = surface(eq)

        # generate image
        image = raycast( s, res)

        # save image to file and display
        plt.subplot(2,2, k+1)
        plt.imshow( image, cmap="Greys_r")

    plt.savefig( './figures/raycast.pdf')
    plt.show()

main()

#surface(rotato()).intersect([0,0.5])
