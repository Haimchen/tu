# -*- coding: utf-8 -*-
"""
Created on Thu Dec 12 14:52:29 2013

@author: lessig
"""

# imports, system
import numpy as np


class Sphere :
    """
    A sphere.
    """

    def __init__( self, pos, radius) :
        """Constructor"""

        self.pos = pos
        self.radius = radius


    def intersect( self, r_orig) :
        """
        Compute intersection point or ray with sphere

        Inputs:
        r_orig: origin of ray (direction is fixed to (0,0,-1) by construction)

        Return:
        ipoint: intersection point if ray intersects sphere as np vector of size 3);
                otherwise np vector of size 0
        """

        # compute radicand to test if there exists an intersection point
        dx = r_orig[0] - self.pos[0]
        dy = r_orig[1] - self.pos[1]
        radicand = (self.radius * self.radius) - (dx * dx) - (dy * dy)

        # no intersection point
        if( radicand < 0.0) :
            return np.zeros((0))

        # compute distance value along ray
        t = -1.0 * (self.pos[2] + np.sqrt( radicand))

        return np.array( [r_orig[0], r_orig[1], -t])


    def shade( self, ipoint) :
        """
        Compute shading at intersection point using simple Lambertian-like model.

        Inputs:
        ipoint: intersection point with sphere

        Returns:
        y : intensity value of reflected light (monochromatic)
        """

        # normal vector at intesection point
        n = ipoint - self.pos
        assert( np.abs(np.linalg.norm( n) - self.radius) < 10.0 * np.finfo( ipoint.dtype).eps )
        # unit normal is needed for shading
        n /= np.linalg.norm( n)

        # simple Lambertian-like shading
        # (equivalent to n.z)
        y = np.dot( np.array( [0.0, 0.0, 1.0]), n)
        assert( y > 0.0)

        return y
