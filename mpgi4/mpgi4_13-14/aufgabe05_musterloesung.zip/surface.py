# -*- coding: utf-8 -*-
"""
Created on Thu Dec 12 14:52:29 2013

@author: herholz
"""

# imports, system
import numpy as np
import scipy.optimize


def find_root(func, z_0, dfunc):
    z_max = None
    for z_0 in np.arange(-1.0, 1.0, 0.1):
        try:
            z = scipy.optimize.newton(func, z_0,  dfunc)
            if abs(z) > 1: continue
            if z_max == None or z > z_max: z_max = z
        except RuntimeError:
            continue
    return z_max


class surface :
    def __init__( self, fun) :
        """Constructor"""
        self.fun = fun

    def intersect( self, r_orig) :
        """
        Compute intersection point or ray with sphere

        Inputs:
        r_orig: origin of ray (direction is fixed to (0,0,-1) by construction)

        Return:
        ipoint: intersection point if ray intersects sphere as np vector of size 3);
                otherwise np vector of size 0
        """
        #rts = np.roots(self.fun.poly(r_orig))
        #rts = map(np.real, filter(lambda x: abs(np.imag(x)) < 1e-12 and np.real(x) > -1 and np.real(x) < 1, rts))
        #if len(rts) > 0:
        #    print r_orig, rts

        #if len(rts) == 0:
        #    return np.array([])
        #else:
        #    return np.array([r_orig[0], r_orig[1], np.min(rts)])

        f = lambda z: self.fun.f([r_orig[0], r_orig[1], z])
        df = lambda z: self.fun.dfz([r_orig[0], r_orig[1], z])
        z = find_root(f, -5, df)
        return np.array([r_orig[0], r_orig[1], z]) if z != None else None

    def shade( self, ipoint) :
        """
        Compute shading at intersection point using simple Lambertian-like model.

        Inputs:
        ipoint: intersection point with sphere

        Returns:
        y : intensity value of reflected light (monochromatic)
        """

        grad = self.fun.df(ipoint)
        if grad[2] > 0:
            grad *= -1
            
        grad /= np.linalg.norm(grad)
        
        return -grad[2]
